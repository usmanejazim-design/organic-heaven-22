import type { PaymentMethod } from './supabase';

export interface Product {
  id: string;
  name: string;
  shortName: string;
  tagline: string;
  description: string;
  price: number; // PKR
  image: string;
  badges: { label: string; icon: string }[];
  comingSoon?: boolean;
}

export const products: Product[] = [
  {
    id: 'herbal-soap',
    name: 'ORGANIC HEAVEN Pure Herbal Soap',
    shortName: 'Pure Herbal Soap',
    tagline: 'Gentle Care, Naturally Beautiful Skin',
    description:
      'Crafted with skin-friendly herbal ingredients. Cleanses deeply while helping maintain skin moisture. Leaves your skin soft, fresh, and naturally clean. Suitable for daily use on all skin types. Free from harsh chemicals.',
    price: 890,
    image: '/items/soap_.jpeg',
    comingSoon: true,
    badges: [
      { label: '100% Natural', icon: 'Leaf' },
      { label: 'Chemical Free', icon: 'ShieldCheck' },
      { label: 'Daily Use', icon: 'Droplets' },
    ],
  },
  {
    id: 'glow-face-mask',
    name: 'ORGANIC HEAVEN Herbal Glow Face Mask',
    shortName: 'Herbal Glow Face Mask',
    tagline: 'Reveal Your Natural Glow with Every Application',
    description:
      'Made with carefully selected natural herbal ingredients. Helps remove excess oil, dirt, and impurities. Leaves skin feeling fresh, smooth, and refreshed. Supports a brighter, healthier-looking complexion. Suitable for all skin types.',
    price: 590,
    image: '/items/face_cream_item_.jpeg',
    badges: [
      { label: 'Brightens Skin', icon: 'Sparkles' },
      { label: '100% Natural', icon: 'Leaf' },
      { label: 'All Skin Types', icon: 'HeartHandshake' },
    ],
  },
  {
    id: 'miracle-hair-oil',
    name: "ORGANIC HEAVEN Miracle Hair Oil",
    shortName: 'Miracle Hair Oil',
    tagline: "Nature's Secret for Stronger, Healthier & Shinier Hair",
    description:
      'Enriched with premium natural herbal oils. Helps reduce hair fall and supports healthy hair growth. Nourishes the scalp and strengthens hair from the roots. Adds natural shine and softness without a greasy feel. Suitable for both men and women.',
    price: 2149,
    image: '/items/hair_iteam_.jpeg',
    badges: [
      { label: 'Reduces Hair Fall', icon: 'ShieldCheck' },
      { label: 'For Men & Women', icon: 'HeartHandshake' },
      { label: 'Non-Greasy', icon: 'Droplets' },
    ],
  },
  {
    id: 'glow-growth-combo',
    name: 'ORGANIC HEAVEN Glow & Growth Combo',
    shortName: 'Glow & Growth Combo',
    tagline: 'Herbal Glow Face Mask + Miracle Hair Oil — Save Rs 239',
    description:
      'Our two best-sellers bundled for the complete natural care ritual. The Herbal Glow Face Mask refreshes and brightens your skin, while the Miracle Hair Oil nourishes your scalp and strengthens hair from the roots. A perfect duo for skin and hair, suitable for both men and women.',
    price: 2500,
    image: '/items/hair_iteam_.jpeg',
    badges: [
      { label: 'Best Value', icon: 'Sparkles' },
      { label: 'Save Rs 239', icon: 'ShieldCheck' },
      { label: 'For Men & Women', icon: 'HeartHandshake' },
    ],
  },
];

export function getProduct(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}

export interface PaymentMethodInfo {
  id: PaymentMethod;
  label: string;
  subtitle: string;
  fields: { label: string; hint: string }[];
}

export const paymentMethods: PaymentMethodInfo[] = [
  {
    id: 'jazzcash',
    label: 'JazzCash',
    subtitle: 'Send payment to our merchant number',
    fields: [{ label: 'JazzCash Sender Number / Trx ID', hint: 'Enter the number you sent from or transaction ID' }],
  },
  {
    id: 'easypaisa',
    label: 'EasyPaisa',
    subtitle: 'Send payment to our EasyPaisa account',
    fields: [{ label: 'EasyPaisa Sender Number / Trx ID', hint: 'Enter the number you sent from or transaction ID' }],
  },
  {
    id: 'bank',
    label: 'Bank Transfer',
    subtitle: 'Transfer to our bank account',
    fields: [
      { label: 'Account Title', hint: 'ORGANIC HEAVEN Pvt Ltd' },
      { label: 'Account Number', hint: '0012345678901' },
      { label: 'IBAN', hint: 'PK36MEZN0001234567890123' },
    ],
  },
  {
    id: 'cod',
    label: 'Cash on Delivery',
    subtitle: 'Pay in cash when your order arrives',
    fields: [],
  },
];

export const paymentAccounts: Record<PaymentMethod, { merchant: string; label: string }[]> = {
  jazzcash: [{ merchant: '0300-1234567', label: 'JazzCash Merchant' }],
  easypaisa: [{ merchant: '0345-7654321', label: 'EasyPaisa Merchant' }],
  bank: [
    { merchant: 'ORGANIC HEAVEN Pvt Ltd', label: 'Account Title' },
    { merchant: '00123-4567890-1', label: 'Account Number' },
    { merchant: 'PK36MEZN0001234567890123', label: 'IBAN' },
  ],
  cod: [],
};


