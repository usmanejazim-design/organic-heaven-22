/*
# Create orders table for ORGANIC HEAVEN storefront

## Purpose
Stores every customer order placed from the storefront checkout form.
The admin control panel reads and updates these rows (status changes).

## New Tables
- `orders`
  - `id`              uuid, primary key
  - `order_number`    text, unique — human-readable order id (e.g. OH-1001), auto-generated
  - `customer_name`   text, not null — full name of customer
  - `phone`           text, not null — contact phone number
  - `address`         text, not null — full shipping address (house#, street, city)
  - `product_id`      text, not null — internal product id (e.g. herbal-soap)
  - `product_name`    text, not null — product title at time of order
  - `quantity`        integer, not null, default 1
  - `unit_price`      numeric(12,2), not null — price per unit at time of order (PKR)
  - `total_amount`    numeric(12,2), not null — quantity * unit_price
  - `payment_method`  text, not null — jazzcash | easypaisa | bank | cod
  - `payment_reference` text — customer's transaction ref / sender number (nullable for COD)
  - `status`          text, not null, default 'pending' — pending | confirmed | delivered
  - `created_at`      timestamptz, default now()

## Other DB objects
- Sequence `orders_seq` starting at 1001 — backs the order number generator.
- Function `generate_order_number()` — returns 'OH-<seq>' using nextval.

## Security (RLS)
- Enable RLS on `orders`.
- Single-tenant storefront with NO customer sign-in, plus a simple client-side
  admin gate (username/password). Both the storefront (insert orders) and the
  admin panel (read/update orders) talk to Supabase with the anon key, so all
  CRUD policies are scoped `TO anon, authenticated`.
- This is intentionally public/shared data per the no-auth design.

## Notes
- Order number is auto-filled by the database default, so the storefront insert
  omits it. The generated value is returned to the UI for the success message.
- Indexes added on `status`, `payment_method`, and `created_at` for admin
  filtering/search performance.
*/

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE,
  customer_name text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  product_id text NOT NULL,
  product_name text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  unit_price numeric(12,2) NOT NULL,
  total_amount numeric(12,2) NOT NULL,
  payment_method text NOT NULL,
  payment_reference text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_orders" ON orders;
CREATE POLICY "anon_select_orders"
  ON orders FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_orders" ON orders;
CREATE POLICY "anon_insert_orders"
  ON orders FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_orders" ON orders;
CREATE POLICY "anon_update_orders"
  ON orders FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_orders" ON orders;
CREATE POLICY "anon_delete_orders"
  ON orders FOR DELETE
  TO anon, authenticated USING (true);

CREATE SEQUENCE IF NOT EXISTS orders_seq START 1001;

CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS text AS $$
DECLARE
  next_val bigint;
BEGIN
  next_val := nextval('orders_seq');
  RETURN 'OH-' || next_val::text;
END;
$$ LANGUAGE plpgsql;

-- Set auto-generated order number default only if not already set
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'order_number'
      AND column_default IS NOT NULL
  ) THEN
    ALTER TABLE orders ALTER COLUMN order_number SET DEFAULT generate_order_number();
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_payment_method ON orders(payment_method);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
