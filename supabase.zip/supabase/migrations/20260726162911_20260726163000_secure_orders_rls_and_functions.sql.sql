/*
# Secure orders table: fix function search_path + lock RLS to authenticated admin

## Purpose
Remediate the security findings on the orders table:
1. `generate_order_number()` had a mutable search_path.
2. RLS policies for INSERT/UPDATE/DELETE on `orders` were always-true,
   allowing any anon-key client to read/modify/delete every order
   (customer name, phone, address — a PII leak).

## Root cause
The storefront has no real Supabase auth. The "admin" gate was purely
client-side (hardcoded credentials in page source), so the database had
no way to distinguish an admin from a visitor. The write policies had
nothing to check against, so they were all `true`.

## Fix
1. Add real Supabase email/password auth for the admin panel
   (admin user created out-of-band).
2. Lock order SELECT/UPDATE/DELETE to `authenticated` users only —
   i.e. the signed-in admin. Visitors can no longer read or edit orders.
3. Replace direct INSERT with a SECURITY DEFINER function `place_order()`
   so visitors can still place orders without a session, but the function
   (not the visitor) owns the insert and enforces server-side validation.
4. Revoke direct INSERT/UPDATE/DELETE table privileges from `anon` so the
   only write path for visitors is `place_order()`.
5. Fix `generate_order_number()` search_path by setting a fixed
   `search_path = public` on the function.

## Objects changed
- Function `generate_order_number()` — recreated with fixed search_path
  (dropped with CASCADE to clear the column-default dependency, then the
  default is re-attached immediately; no data is lost).
- New function `place_order(...)` — SECURITY DEFINER, search_path = public,
  validates and inserts a new order, returns the generated order_number.
- Table `orders`:
  - RLS stays enabled.
  - SELECT/INSERT/UPDATE/DELETE policies: authenticated only.
- Privileges:
  - `anon` loses direct INSERT/UPDATE/DELETE on orders (can only call
    place_order(), which is GRANT EXECUTE TO anon, authenticated).
  - `authenticated` keeps full table CRUD for managing orders.

## Frontend impact
- Storefront order form now calls `place_order()` RPC instead of a direct
  table insert. No visible change to the customer.
- Admin panel must sign in via Supabase email/password
  (admin@organicheaven.pk). The old client-side credential check is removed.
*/

-- 1. Fix generate_order_number() search_path
-- Drop with CASCADE to clear the column-default dependency, then re-attach.
DROP FUNCTION IF EXISTS public.generate_order_number() CASCADE;
CREATE FUNCTION public.generate_order_number()
RETURNS text
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  next_val bigint;
BEGIN
  next_val := nextval('orders_seq');
  RETURN 'OH-' || next_val::text;
END;
$$;

-- Re-attach the column default to the (now secure) function
ALTER TABLE orders ALTER COLUMN order_number SET DEFAULT public.generate_order_number();

-- 2. Secure place_order() RPC for storefront visitors
CREATE OR REPLACE FUNCTION public.place_order(
  p_customer_name text,
  p_phone text,
  p_address text,
  p_product_id text,
  p_product_name text,
  p_quantity integer,
  p_unit_price numeric(12,2),
  p_total_amount numeric(12,2),
  p_payment_method text,
  p_payment_reference text
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_order_number text;
BEGIN
  -- Server-side validation (defense even if client is bypassed)
  IF btrim(p_customer_name) = '' THEN
    RAISE EXCEPTION 'Customer name is required';
  END IF;
  IF p_quantity < 1 THEN
    RAISE EXCEPTION 'Quantity must be at least 1';
  END IF;
  IF p_unit_price < 0 OR p_total_amount < 0 THEN
    RAISE EXCEPTION 'Invalid price';
  END IF;
  IF p_payment_method NOT IN ('jazzcash', 'easypaisa', 'bank', 'cod') THEN
    RAISE EXCEPTION 'Invalid payment method';
  END IF;

  INSERT INTO orders (
    customer_name, phone, address, product_id, product_name,
    quantity, unit_price, total_amount, payment_method, payment_reference
  ) VALUES (
    btrim(p_customer_name), btrim(p_phone), btrim(p_address),
    p_product_id, p_product_name, p_quantity, p_unit_price, p_total_amount,
    p_payment_method, NULLIF(btrim(p_payment_reference), '')
  )
  RETURNING order_number INTO new_order_number;

  RETURN new_order_number;
END;
$$;

GRANT EXECUTE ON FUNCTION public.place_order(text, text, text, text, text, integer, numeric, numeric, text, text) TO anon, authenticated;

-- 3. Replace always-true RLS policies with authenticated-only ones

DROP POLICY IF EXISTS "anon_select_orders" ON orders;
DROP POLICY IF EXISTS "anon_insert_orders" ON orders;
DROP POLICY IF EXISTS "anon_update_orders" ON orders;
DROP POLICY IF EXISTS "anon_delete_orders" ON orders;

CREATE POLICY "admin_select_orders"
  ON orders FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "admin_insert_orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "admin_update_orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "admin_delete_orders"
  ON orders FOR DELETE
  TO authenticated
  USING (true);

-- 4. Revoke direct write privileges from anon so visitors MUST use place_order()
REVOKE INSERT, UPDATE, DELETE ON orders FROM anon;
GRANT INSERT, UPDATE, DELETE ON orders TO authenticated;
