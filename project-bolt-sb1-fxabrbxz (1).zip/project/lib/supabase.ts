import { createClient, type Session, type User } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: { persistSession: true },
});

export const ADMIN_EMAIL = 'admin@organicheaven.pk';

export type OrderStatus = 'pending' | 'confirmed' | 'delivered';
export type PaymentMethod = 'jazzcash' | 'easypaisa' | 'bank' | 'cod';

export interface OrderRow {
  id: string;
  order_number: string | null;
  customer_name: string;
  phone: string;
  address: string;
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_amount: number;
  payment_method: PaymentMethod;
  payment_reference: string | null;
  status: OrderStatus;
  created_at: string;
}

export interface NewOrder {
  customer_name: string;
  phone: string;
  address: string;
  product_id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_amount: number;
  payment_method: PaymentMethod;
  payment_reference?: string | null;
}

export async function placeOrder(order: NewOrder): Promise<{ orderNumber: string | null }> {
  const { data, error } = await supabase.rpc('place_order', {
    p_customer_name: order.customer_name,
    p_phone: order.phone,
    p_address: order.address,
    p_product_id: order.product_id,
    p_product_name: order.product_name,
    p_quantity: order.quantity,
    p_unit_price: order.unit_price,
    p_total_amount: order.total_amount,
    p_payment_method: order.payment_method,
    p_payment_reference: order.payment_reference ?? null,
  });
  if (error) throw error;
  return { orderNumber: (data as string | null) ?? null };
}

export async function fetchOrders(): Promise<OrderRow[]> {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as OrderRow[];
}

export async function updateOrderStatus(id: string, status: OrderStatus): Promise<void> {
  const { error } = await supabase.from('orders').update({ status }).eq('id', id);
  if (error) throw error;
}

export async function signInAdmin(email: string, password: string): Promise<void> {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
}

export async function signOutAdmin(): Promise<void> {
  await supabase.auth.signOut();
}

export function onAuthChange(cb: (session: Session | null, user: User | null) => void) {
  return supabase.auth.onAuthStateChange((_event, session) => {
    cb(session, session?.user ?? null);
  });
}
